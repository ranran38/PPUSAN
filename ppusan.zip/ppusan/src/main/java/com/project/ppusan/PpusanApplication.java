package com.project.ppusan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PpusanApplication {

	public static void main(String[] args) {
		SpringApplication.run(PpusanApplication.class, args);
	}

}
